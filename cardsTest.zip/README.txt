How to Run the Test Suite

Requirements:
- Java 11 or higher
- Maven 3.6+

Steps:
1. Navigate to the project root directory (where pom.xml is located)
1. Extract the cardsTest.zip file
2. Navigate to the extracted directory
3. Run: mvn test

This will execute all test suites and display the results in the console.
